# 우리끄투

끄투 온라인의 오픈소스 사전으로 만든 끝말잇기 웹게임이에요. 혼자 봇이랑 연습하거나, 방을 만들어 친구들과 실시간으로 대결할 수 있어요.

- 사전: 명사 약 21만 개 (두음법칙 적용: 력 → 역, 녀 → 여, 라 → 나)
- 봇 대전: 쉬움 · 보통 · 어려움(한방 단어로 공격)
- 멀티플레이: 4자리 방 코드, 2~8명, 상대가 입력 중인 글자 표시, 탈락제
- 점수: 글자 수 × 10 + 남은 초 × 2

## 내 컴퓨터에서 실행

[Node.js](https://nodejs.org) 18 이상이 필요해요.

```bash
npm install
npm start
```

브라우저에서 http://localhost:3000 을 열면 돼요. 같은 와이파이의 친구는 `http://내컴퓨터IP:3000` 으로 들어올 수 있어요.

## 인터넷에 올리기

### 방법 1. 서버까지 한 번에 (멀티플레이 가능, 추천)

Node.js를 돌려 주는 무료·저가 호스팅에 이 저장소를 연결하면 돼요. 예: [Render](https://render.com)

1. 이 폴더를 GitHub 저장소로 올려요.
2. Render에서 **New → Web Service** 를 누르고 저장소를 고르세요.
3. Build Command `npm install`, Start Command `npm start` 로 설정하면 끝이에요.

포트는 호스팅이 주는 `PORT` 환경변수를 자동으로 써요.

### 방법 2. GitHub Pages (봇 대전만)

GitHub Pages는 파일만 보여 주는 정적 호스팅이라 서버(`server.js`)가 돌지 않아요. 그래서 봇 대전만 돼요.

1. GitHub Pages는 저장소 맨 위나 `docs` 폴더만 배포할 수 있어요. `public` 폴더를 복사해서 이름을 `docs` 로 바꿔 올리세요.
2. 저장소 **Settings → Pages** 에서 Branch를 `main`, 폴더를 `/docs` 로 고르고 저장하면 몇 분 뒤 주소가 나와요.
3. 멀티플레이도 쓰고 싶으면 방법 1로 서버를 따로 띄우고, `index.html` 의 아래 줄에 서버 주소를 적으세요.

```html
<meta name="kkutu-server" content="wss://내서버주소.onrender.com">
```

## 파일 구성

| 파일 | 설명 |
| --- | --- |
| `server.js` | 정적 파일 제공 + WebSocket 멀티플레이 서버 (방, 턴, 타이머, 단어 검증) |
| `public/index.html` | 게임 화면 (봇 대전은 이 파일만으로 동작) |
| `public/words.txt` | 단어 목록, 한 줄에 한 단어 |

## 라이선스

단어 데이터는 [JJoriping/KKuTu](https://github.com/JJoriping/KKuTu) 의 `db.sql` 에서 표준어·외래어·전문어 명사만 골라 만든 것이에요. 원본이 GPL-3.0이므로 이 프로젝트도 GPL-3.0을 따라요. 자세한 내용은 `LICENSE` 를 보세요.
